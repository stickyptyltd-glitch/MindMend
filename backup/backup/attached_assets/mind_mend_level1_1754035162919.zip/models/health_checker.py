class HealthChecker:
    def scan_text(self, text):
        alerts = []
        keywords = {
            "self-harm": ["kill myself", "suicide", "end it all"],
            "violence": ["hurt someone", "attack", "murder"],
            "severe distress": ["can't go on", "desperate", "worthless"]
        }
        for category, words in keywords.items():
            if any(word in text.lower() for word in words):
                alerts.append(f"⚠️ Possible {category} risk")
        return alerts
