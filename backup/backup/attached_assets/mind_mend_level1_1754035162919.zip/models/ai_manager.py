class AIManager:
    def __init__(self):
        self.models = {
            "default": self.fake_ai_response
        }

    def fake_ai_response(self, text, context="general"):
        return f"[AI Therapist] I hear you saying: '{text}'. Let's explore this together."

    def get_response(self, text, session_type="general"):
        return self.models["default"](text, context=session_type)
