from flask import Flask, render_template, request, jsonify
import sqlite3
from models.ai_manager import AIManager
from models.health_checker import HealthChecker

app = Flask(__name__)
ai_manager = AIManager()
health_checker = HealthChecker()

def init_db():
    conn = sqlite3.connect("data/patients.db")
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    patient_name TEXT,
                    session_type TEXT,
                    input_text TEXT,
                    ai_response TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                 )''')
    conn.commit()
    conn.close()

init_db()

def log_session(patient_name, session_type, input_text, ai_response):
    conn = sqlite3.connect("data/patients.db")
    c = conn.cursor()
    c.execute("INSERT INTO sessions (patient_name, session_type, input_text, ai_response) VALUES (?, ?, ?, ?)",
              (patient_name, session_type, input_text, ai_response))
    conn.commit()
    conn.close()

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/session", methods=["GET", "POST"])
def session():
    if request.method == "POST":
        patient_name = request.form["name"]
        session_type = request.form["session_type"]
        user_input = request.form["user_input"]

        ai_response = ai_manager.get_response(user_input, session_type)
        log_session(patient_name, session_type, user_input, ai_response)

        alerts = health_checker.scan_text(user_input)

        return render_template("session.html", name=patient_name,
                               session_type=session_type,
                               user_input=user_input,
                               ai_response=ai_response,
                               alerts=alerts)
    return render_template("session.html")

@app.route("/api/sessions")
def api_sessions():
    conn = sqlite3.connect("data/patients.db")
    c = conn.cursor()
    c.execute("SELECT * FROM sessions ORDER BY timestamp DESC")
    rows = c.fetchall()
    conn.close()
    return jsonify(rows)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, debug=True)
